import React, { useEffect, useState, Fragment } from "react";
import {Nav, Navbar} from 'react-bootstrap'
// import { Link } from "react-router-dom";
// import Logout from "../../views/auth/Logout";
function Navigation() {

  const [isAuth, setIsAuth] = useState(false);

  useEffect(() => {
    if (localStorage.getItem('token') !== null) {
      setIsAuth(true);
    }
  }, []);

  const handleClick = () => {
    localStorage.clear();
    window.location.reload();
  }


    return(
      <>
<nav class="navbar navbar-dark bg-dark">
  {isAuth === true ? (

    <Fragment>
      {''}   
      <div class="container-fluid">
  <Navbar bg="myRed" variant="dark" sticky="top" expand="sm" collapseOnSelect>
  <a href ="/"> <Navbar.Brand>
      </Navbar.Brand></a>
      <Navbar.Toggle />
      <Navbar.Collapse>
      <Nav>
      <div class="nav-link px-3">Welcome User</div>
        <Nav.Link href='dashboard'>Dashboard</Nav.Link>
        {/* <Nav.Link href='login'>Login</Nav.Link> */}
        <Nav.Link href='plot'>Plot Data</Nav.Link>
        <Nav.Link href='house'>House Data</Nav.Link>
        <Nav.Link href='tenant'>Tenant Data</Nav.Link>
        {/* <Nav.Link href='logout'>Logout</Nav.Link> */}
      </Nav>
      {/* <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form> */}
      </Navbar.Collapse>
      </Navbar>
    
      <div class="navbar-nav">
    <div class="nav-item text-nowrap">
      {/* <Link to='logout'>Logout</Link> */}
      <button 
      type="button" 
      class="btn btn-sm btn-outline-danger" 
      onClick={handleClick}>Logout</button>
    </div>
  </div>
  </div>
    </Fragment>
  ):(
    <Fragment>
      {''}
      <div class="nav-item text-nowrap">
      <button 
      type="button" 
      class="btn btn-sm btn-outline-danger" 
      >Signup</button>
    </div>
    </Fragment>
  )}
  
</nav>
      </>
    )
}

export default Navigation;