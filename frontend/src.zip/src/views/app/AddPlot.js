import React from 'react';

function AddPlot () {

    return (
        <>
        <b>Add Plot Information</b>
        </>

    )
}

export default AddPlot;