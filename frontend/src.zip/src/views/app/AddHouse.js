import React from 'react'


function AddHouse (){

    return (

        <>
        
        <b>Add House</b>
        </>




    )





}

export default AddHouse;