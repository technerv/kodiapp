import React from 'react'

function AddTenant (){


    return (

        <>
        <b>Add House</b>
        </>
    )
}

export default AddTenant;