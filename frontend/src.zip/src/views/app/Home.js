import React from 'react';


function Home () {
    return (
        <div className='container'>
            <div className='card mt-4'>
                <div className='card-body'>
                    <div className='content'>
                    <p>Are You Are A Property Owner Or Tenant, Kodi Allows You To Manage Your Rental Property With A Click. Sign Up for a demo account</p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Home;