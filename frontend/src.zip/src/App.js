import './App.css';
// import logo from './logo.svg'

import {BrowserRouter, Routes, Route} from 'react-router-dom'

import Login from './views/auth/Login';
import Signup from './views/auth/Signup';
import Logout from './views/auth/Logout';
import Dashboard from './views/app/Dashboard'
import Plot from './views/app/Plot';
import AddPlot from './views/app/AddPlot';
import House from './views/app/House';
import Tenant from './views/app/Tenant';
import Footer from './components/layout/Footer';
import Navigation from './components/layout/Navigation';
import AddHouse from './views/app/AddHouse';
import AddTenant from './views/app/AddTenant';

function App() {
  return (
    <>
    <Navigation />
    
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Login />} />
      {/* <Route path='login' element={<Login />} /> */}

      <Route path='/signup' element={<Signup />} />
     {/* {localStorage.getItem('token')?<Route path='dashboard' element={<Dashboard />} /> : <Navigate to={'/'}/> }  */}

     <Route path='/logout' element={<Logout />} />


     <Route path='/dashboard' element={<Dashboard />} />

      <Route path='/plot' element={<Plot />} />
      {/* {localStorage.getItem('token')?<Route path='plot' element={<Plot />} /> : <Navigate to={'/'}/> }  */}
      <Route path='/addPlot' element={<AddPlot />} />
      {/* {localStorage.getItem('token')?<Route path='addplot' element={<AddPlot />} /> : <Navigate to={'/'}/> }  */}

      <Route path='/house' element={<House />} />
      {/* {localStorage.getItem('token')?<Route path='house' element={<House />} /> : <Navigate to={'/'}/> }  */}
      <Route path='/addHouse' element={<AddHouse />} />
      {/* {localStorage.getItem('token')?<Route path='addhouse' element={<AddHouse />} /> : <Navigate to={'/'}/> }  */}
     
      <Route path='/tenant' element={<Tenant />} />
      {/* {localStorage.getItem('token')?<Route path='tenant' element={<Tenant />} /> : <Navigate to={'/'}/> }  */}
      <Route path='/addTenant' element={<AddTenant />}/>
      {/* {localStorage.getItem('token')?<Route path='addtenant' element={<AddTenant />} /> : <Navigate to={'/'}/> }  */}

    </Routes>   
    </BrowserRouter>
    <Footer />
   </>
  )
}

export default App;
